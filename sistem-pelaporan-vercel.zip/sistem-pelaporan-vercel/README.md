# Sistem Pelaporan — Vercel

## Deploy ke Vercel

### 1. Push ke GitHub
```bash
git init
git add .
git commit -m "first commit"
git remote add origin https://github.com/username/repo.git
git push -u origin main
```

### 2. Import di Vercel
- Buka https://vercel.com/new
- Import repo GitHub kamu
- Klik **Deploy**

### 3. Set Environment Variables
Di Vercel Dashboard → Project → **Settings → Environment Variables**, tambahkan:

| Key | Value |
|-----|-------|
| `WEBHOOK_URL` | `https://discord.com/api/webhooks/...` |
| `ACCESS_CODE` | kode rahasia kamu |

Klik **Save** lalu **Redeploy**.

## Struktur
```
├── api/
│   └── kirim.js       ← Serverless function (handle POST /api/kirim)
├── public/
│   └── index.html     ← Frontend
├── vercel.json        ← Routing config
└── package.json
```
